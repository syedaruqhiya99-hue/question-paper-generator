# Automatic Question Paper Generator using Machine Learning

A complete web application that automatically generates balanced, syllabus-aligned question papers using Machine Learning and NLP.

## Features

- Upload syllabus (PDF / TXT) or paste text
- Select question types: MCQ, Short Answer, Long Answer, Fill in the Blanks
- Control total marks, number of questions, and difficulty distribution
- ML-powered question generation using T5-based model
- Automatic marks distribution and paper formatting
- Download question paper as PDF
- Clean and modern Streamlit UI

## Tech Stack

- **Frontend**: Streamlit
- **ML / NLP**: Hugging Face Transformers (T5 Question Generation model)
- **PDF Generation**: fpdf2
- **Language**: Python 3.9+

## Project Structure

```
automatic-question-paper-generator/
├── app.py                      # Main Streamlit application
├── requirements.txt
├── README.md
├── sample_data/
│   └── sample_syllabus.txt
└── src/
    ├── question_generator.py   # ML question generation logic
    └── paper_formatter.py      # Paper assembly & PDF generation
```

## How to Run Locally

1. Clone or download this project
2. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate          # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the app:
   ```bash
   streamlit run app.py
   ```
5. Open the local URL shown in the terminal (usually http://localhost:8501)

> **Note**: First run will download the ML model (~250-500 MB). Make sure you have internet and enough disk space.

## Deploy for Public Link (Free)

### Option 1: Streamlit Community Cloud (Recommended)

1. Push this project to a GitHub repository
2. Go to [https://share.streamlit.io](https://share.streamlit.io)
3. Sign in with GitHub
4. Click "New app" → select your repository → set main file to `app.py`
5. Click Deploy → You will get a public link like `https://your-app-name.streamlit.app`

### Option 2: Hugging Face Spaces

1. Create a new Space on Hugging Face
2. Choose "Streamlit" as SDK
3. Upload the project files
4. It will automatically deploy and give you a public URL

## Sample Usage

1. Paste or upload a syllabus / chapter content
2. Choose exam details (marks, time, difficulty)
3. Select question types and counts
4. Click **Generate Question Paper**
5. Download the PDF

## Limitations & Future Improvements

- Current model works best on clear educational text
- For production use, fine-tune on domain-specific data (NCERT, university papers, etc.)
- Add Bloom’s Taxonomy control, answer key generation, and multi-language support

## Author

Created as an academic / portfolio project – Automatic Question Paper Generator using ML.
