"""
Automatic Question Paper Generator using Machine Learning
Main Streamlit Application
"""

import streamlit as st
import sys
import os
from pathlib import Path

# Add src to path
sys.path.append(str(Path(__file__).parent / "src"))

from question_generator import generate_questions_by_type
from paper_formatter import create_question_paper_pdf, calculate_total_marks

# Page config
st.set_page_config(
    page_title="Automatic Question Paper Generator | ML",
    page_icon="📝",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 0.3rem;
    }
    .sub-header {
        text-align: center;
        color: #555;
        margin-bottom: 2rem;
    }
    .stButton>button {
        width: 100%;
        background-color: #1f77b4;
        color: white;
        font-weight: 600;
        border-radius: 8px;
        height: 3rem;
    }
    .success-box {
        padding: 1rem;
        background-color: #d4edda;
        border-radius: 8px;
        border-left: 5px solid #28a745;
    }
</style>
""", unsafe_allow_html=True)


def load_sample_syllabus():
    sample_path = Path(__file__).parent / "sample_data" / "sample_syllabus.txt"
    if sample_path.exists():
        return sample_path.read_text(encoding="utf-8")
    return ""


def main():
    st.markdown('<p class="main-header">📝 Automatic Question Paper Generator</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Powered by Machine Learning & NLP</p>', unsafe_allow_html=True)

    # Sidebar - Configuration
    with st.sidebar:
        st.header("⚙️ Exam Configuration")

        institution = st.text_input("Institution / Department", value="Department of Computer Science")
        exam_title = st.text_input("Exam Title", value="End Semester Examination")
        subject = st.text_input("Subject Name", value="Machine Learning")
        duration = st.selectbox("Duration", ["1 Hour 30 Minutes", "2 Hours", "3 Hours", "3 Hours 30 Minutes"], index=2)

        st.divider()
        st.subheader("Question Distribution")

        col1, col2 = st.columns(2)
        with col1:
            mcq_count = st.number_input("MCQs", min_value=0, max_value=20, value=5)
            short_count = st.number_input("Short Answer", min_value=0, max_value=15, value=4)
        with col2:
            fill_count = st.number_input("Fill Blanks", min_value=0, max_value=15, value=3)
            long_count = st.number_input("Long Answer", min_value=0, max_value=10, value=2)

        st.divider()
        st.info("💡 Tip: First generation downloads the ML model (~300MB). Subsequent runs are faster.")

    # Main content
    st.subheader("📄 Syllabus / Content Input")

    input_method = st.radio(
        "Choose input method:",
        ["Paste Text", "Upload File (TXT/PDF)", "Use Sample Syllabus"],
        horizontal=True
    )

    context = ""

    if input_method == "Paste Text":
        context = st.text_area(
            "Paste syllabus or chapter content here:",
            height=250,
            placeholder="Paste educational content here (minimum 200-300 characters recommended)..."
        )
    elif input_method == "Upload File (TXT/PDF)":
        uploaded_file = st.file_uploader("Upload syllabus file", type=["txt", "pdf"])
        if uploaded_file is not None:
            if uploaded_file.type == "text/plain":
                context = uploaded_file.read().decode("utf-8")
            else:
                try:
                    from PyPDF2 import PdfReader
                    reader = PdfReader(uploaded_file)
                    context = "\n".join([page.extract_text() or "" for page in reader.pages])
                except Exception as e:
                    st.error(f"Error reading PDF: {e}")
            if context:
                st.success(f"Loaded {len(context)} characters from file.")
                with st.expander("Preview content"):
                    st.text(context[:1500] + ("..." if len(context) > 1500 else ""))
    else:
        context = load_sample_syllabus()
        st.success("Sample Machine Learning syllabus loaded.")
        with st.expander("Preview sample content"):
            st.text(context)

    st.divider()

    # Generate button
    generate_btn = st.button("🚀 Generate Question Paper", type="primary", use_container_width=True)

    if generate_btn:
        if not context or len(context.strip()) < 100:
            st.error("Please provide sufficient content (at least 100 characters) to generate questions.")
            return

        with st.spinner("🔄 Generating questions using Machine Learning model... This may take 30-90 seconds on first run."):
            try:
                questions = generate_questions_by_type(
                    context=context,
                    mcq_count=mcq_count,
                    short_count=short_count,
                    long_count=long_count,
                    fill_count=fill_count
                )

                total_marks = calculate_total_marks(questions)

                # Store in session state
                st.session_state["questions"] = questions
                st.session_state["total_marks"] = total_marks
                st.session_state["meta"] = {
                    "exam_title": exam_title,
                    "subject": subject,
                    "duration": duration,
                    "institution": institution
                }

                st.success(f"✅ Question paper generated successfully! Total Marks: {total_marks}")

            except Exception as e:
                st.error(f"Error during generation: {str(e)}")
                st.exception(e)
                return

    # Display results if available
    if "questions" in st.session_state:
        questions = st.session_state["questions"]
        total_marks = st.session_state["total_marks"]
        meta = st.session_state["meta"]

        st.subheader("📋 Generated Question Paper Preview")

        for qtype, qlist in questions.items():
            if not qlist:
                continue
            st.markdown(f"### {qtype}")
            for i, item in enumerate(qlist, 1):
                st.markdown(f"**Q{i}.** {item['question']}")
                if qtype == "MCQ" and "options" in item:
                    for idx, opt in enumerate(item["options"]):
                        st.write(f"   {chr(65+idx)}) {opt}")
                st.write("")

        # Download PDF
        st.divider()
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            try:
                pdf_bytes = create_question_paper_pdf(
                    questions=questions,
                    exam_title=meta["exam_title"],
                    subject=meta["subject"],
                    total_marks=total_marks,
                    duration=meta["duration"],
                    institution=meta["institution"]
                )
                st.download_button(
                    label="📥 Download Question Paper (PDF)",
                    data=pdf_bytes,
                    file_name=f"Question_Paper_{meta['subject'].replace(' ', '_')}.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )
            except Exception as e:
                st.error(f"PDF generation error: {e}")

        st.markdown("---")
        st.caption("Generated by Automatic Question Paper Generator using ML • Academic Project")


if __name__ == "__main__":
    main()
