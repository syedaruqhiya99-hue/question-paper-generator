"""
Question Generator Module
Uses a T5-based model for automatic question generation from educational text.
"""

import re
import random
from typing import List, Dict, Optional
import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

class QuestionGenerator:
    def __init__(self, model_name: str = "valhalla/t5-small-qg-hl"):
        """
        Initialize the question generation model.
        Default model is lightweight and suitable for CPU.
        """
        self.model_name = model_name
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = None
        self.model = None
        self._loaded = False

    def load_model(self):
        """Lazy load the model only when needed."""
        if self._loaded:
            return
        print(f"Loading model {self.model_name} on {self.device}...")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_name)
        self.model.to(self.device)
        self.model.eval()
        self._loaded = True
        print("Model loaded successfully.")

    def _highlight_answer(self, context: str, answer: str) -> str:
        """Format context with highlighted answer for the QG model."""
        # Simple highlight: replace first occurrence
        if answer.lower() in context.lower():
            # Case-insensitive replace for highlighting
            pattern = re.compile(re.escape(answer), re.IGNORECASE)
            highlighted = pattern.sub(f"<hl> {answer} <hl>", context, count=1)
            return highlighted
        return f"{context} <hl> {answer} <hl>"

    def generate_from_context(self, context: str, num_questions: int = 3) -> List[str]:
        """
        Generate questions from a given context using the T5 QG model.
        """
        self.load_model()

        # Split context into smaller chunks if too long
        sentences = re.split(r'(?<=[.!?])\s+', context.strip())
        sentences = [s.strip() for s in sentences if len(s.strip()) > 30]

        if not sentences:
            return []

        questions = []
        attempts = 0
        max_attempts = num_questions * 4

        while len(questions) < num_questions and attempts < max_attempts:
            attempts += 1
            # Pick a random sentence or short paragraph as answer span
            answer = random.choice(sentences)
            if len(answer) > 120:
                answer = answer[:120]

            # Create input with highlight
            input_text = f"generate question: {self._highlight_answer(context[:512], answer)}"

            inputs = self.tokenizer(
                input_text,
                max_length=512,
                truncation=True,
                padding="max_length",
                return_tensors="pt"
            ).to(self.device)

            with torch.no_grad():
                outputs = self.model.generate(
                    input_ids=inputs["input_ids"],
                    attention_mask=inputs["attention_mask"],
                    max_length=64,
                    num_beams=4,
                    early_stopping=True,
                    no_repeat_ngram_size=2
                )

            question = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            question = question.strip()

            # Basic cleaning and filtering
            if question and len(question) > 15 and question not in questions:
                # Ensure it ends with ?
                if not question.endswith("?"):
                    question += "?"
                questions.append(question)

        return questions[:num_questions]

    def generate_mcq(self, context: str, num_questions: int = 3) -> List[Dict]:
        """
        Generate MCQ style questions.
        For simplicity we generate the question and create plausible options.
        """
        base_questions = self.generate_from_context(context, num_questions)
        mcqs = []

        # Simple distractor generation (can be improved with better methods)
        distractors_pool = [
            "None of the above",
            "All of the above",
            "Cannot be determined",
            "Both A and B",
            "Insufficient data"
        ]

        for q in base_questions:
            # Create a simple structure
            options = [
                "Option A (Correct concept from text)",
                random.choice(distractors_pool),
                "Option C (Related but incorrect)",
                "Option D (Unrelated concept)"
            ]
            random.shuffle(options)
            correct = options[0]  # In real system we would track the real answer

            mcqs.append({
                "question": q,
                "options": options,
                "answer": correct,
                "type": "MCQ"
            })
        return mcqs

    def generate_short_answer(self, context: str, num_questions: int = 3) -> List[Dict]:
        questions = self.generate_from_context(context, num_questions)
        return [{"question": q, "type": "Short Answer", "marks": 2} for q in questions]

    def generate_long_answer(self, context: str, num_questions: int = 2) -> List[Dict]:
        questions = self.generate_from_context(context, num_questions)
        # Make them more elaborate
        long_qs = []
        for q in questions:
            if not q.lower().startswith(("explain", "describe", "discuss", "compare")):
                q = "Explain in detail: " + q
            long_qs.append({"question": q, "type": "Long Answer", "marks": 5})
        return long_qs

    def generate_fill_blanks(self, context: str, num_questions: int = 3) -> List[Dict]:
        """Simple rule-based fill-in-the-blanks from key sentences."""
        sentences = re.split(r'(?<=[.!?])\s+', context.strip())
        sentences = [s for s in sentences if 40 < len(s) < 180]

        fill_qs = []
        used = set()

        for sent in sentences:
            if len(fill_qs) >= num_questions:
                break
            words = sent.split()
            if len(words) < 6:
                continue
            # Blank a content word (not first/last)
            idx = random.randint(2, len(words) - 3)
            answer = words[idx]
            if answer.lower() in used or len(answer) < 4:
                continue
            used.add(answer.lower())
            words[idx] = "__________"
            question = " ".join(words)
            fill_qs.append({
                "question": question,
                "answer": answer,
                "type": "Fill in the Blanks",
                "marks": 1
            })
        return fill_qs


def generate_questions_by_type(
    context: str,
    mcq_count: int = 5,
    short_count: int = 3,
    long_count: int = 2,
    fill_count: int = 3
) -> Dict[str, List]:
    """
    High-level function used by the Streamlit app.
    """
    qg = QuestionGenerator()

    results = {
        "MCQ": qg.generate_mcq(context, mcq_count) if mcq_count > 0 else [],
        "Short Answer": qg.generate_short_answer(context, short_count) if short_count > 0 else [],
        "Long Answer": qg.generate_long_answer(context, long_count) if long_count > 0 else [],
        "Fill in the Blanks": qg.generate_fill_blanks(context, fill_count) if fill_count > 0 else []
    }
    return results
