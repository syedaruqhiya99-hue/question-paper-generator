"""
Paper Formatter Module
Assembles questions into a proper question paper and generates PDF.
"""

from fpdf import FPDF
from typing import List, Dict, Optional
from datetime import datetime
import io


class QuestionPaperPDF(FPDF):
    def __init__(self, title: str = "Question Paper", institution: str = ""):
        super().__init__()
        self.title = title
        self.institution = institution
        self.set_auto_page_break(auto=True, margin=15)

    def header(self):
        self.set_font("Helvetica", "B", 14)
        if self.institution:
            self.cell(0, 8, self.institution, align="C", new_x="LMARGIN", new_y="NEXT")
        self.set_font("Helvetica", "B", 12)
        self.cell(0, 8, self.title, align="C", new_x="LMARGIN", new_y="NEXT")
        self.ln(4)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")


def create_question_paper_pdf(
    questions: Dict[str, List],
    exam_title: str = "End Semester Examination",
    subject: str = "Machine Learning",
    total_marks: int = 100,
    duration: str = "3 Hours",
    institution: str = "Department of Computer Science",
    instructions: Optional[List[str]] = None
) -> bytes:
    """
    Create a professionally formatted question paper PDF.
    Returns PDF as bytes.
    """
    pdf = QuestionPaperPDF(title=exam_title, institution=institution)
    pdf.add_page()
    pdf.set_font("Helvetica", size=11)

    # Header info
    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(95, 8, f"Subject: {subject}", border=0)
    pdf.cell(95, 8, f"Total Marks: {total_marks}", border=0, align="R", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(95, 8, f"Duration: {duration}", border=0)
    pdf.cell(95, 8, f"Date: {datetime.now().strftime('%d-%m-%Y')}", border=0, align="R", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(6)

    # Instructions
    if instructions is None:
        instructions = [
            "All questions are compulsory unless otherwise stated.",
            "Read each question carefully before answering.",
            "Write neat and legible answers.",
            "Marks for each question are indicated against it."
        ]

    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(0, 8, "General Instructions:", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", size=10)
    for i, inst in enumerate(instructions, 1):
        pdf.multi_cell(0, 6, f"{i}. {inst}")
    pdf.ln(8)

    # Question sections
    question_number = 1
    section_marks = {
        "MCQ": 1,
        "Fill in the Blanks": 1,
        "Short Answer": 2,
        "Long Answer": 5
    }

    for qtype, qlist in questions.items():
        if not qlist:
            continue

        pdf.set_font("Helvetica", "B", 12)
        marks_per = section_marks.get(qtype, 2)
        total_section = marks_per * len(qlist)
        pdf.cell(0, 9, f"Section: {qtype}  (Marks: {total_section})", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)

        for item in qlist:
            pdf.set_font("Helvetica", "B", 10)
            q_text = item.get("question", "")
            marks = item.get("marks", marks_per)

            # Question number + text
            pdf.multi_cell(0, 6, f"Q{question_number}. {q_text}  [{marks} mark{'s' if marks > 1 else ''}]")
            
            # Options for MCQ
            if qtype == "MCQ" and "options" in item:
                pdf.set_font("Helvetica", size=10)
                for idx, opt in enumerate(item["options"]):
                    label = chr(65 + idx)  # A, B, C, D
                    pdf.cell(0, 6, f"    {label}) {opt}", new_x="LMARGIN", new_y="NEXT")
            
            pdf.ln(3)
            question_number += 1

        pdf.ln(4)

    # End note
    pdf.ln(6)
    pdf.set_font("Helvetica", "I", 10)
    pdf.cell(0, 8, "***** ALL THE BEST *****", align="C")

    # Output as bytes
    return bytes(pdf.output())


def calculate_total_marks(questions: Dict[str, List]) -> int:
    total = 0
    default_marks = {
        "MCQ": 1,
        "Fill in the Blanks": 1,
        "Short Answer": 2,
        "Long Answer": 5
    }
    for qtype, qlist in questions.items():
        for item in qlist:
            total += item.get("marks", default_marks.get(qtype, 1))
    return total
